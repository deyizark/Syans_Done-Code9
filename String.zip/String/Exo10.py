#Retire tout espas ki nan yon chenn, epi kole chenn sa ak kantite karaktè li genyen (Pa kontwole espas yo).

s = "Ayiti kapab avanse"
chennsanespas = s.replace(' ', '')
rezilta = chennsanespas + str(len(chennsanespas))
print(rezilta)  