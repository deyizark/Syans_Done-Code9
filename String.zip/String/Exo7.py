#Afiche endeks premye karaktè "a" ki nan yon chenn

s = "Ayiti kapab avanse"
result = s.index('a')
print(result)  