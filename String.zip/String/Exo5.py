#Ranplase tout karaktè "a" ki nan yon chenn pa "@"

chenn = "Ayibobo Ayiti"
rezilta = chenn.replace('A', '@')
print(rezilta)  