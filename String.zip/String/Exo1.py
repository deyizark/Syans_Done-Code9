# Nan yon chenn karaktè, mete tout karaktè yo an miniskil.

chenn = "Ayibobo Ayiti"
rezilta = chenn.lower()
print(rezilta)  