#Nan yon chenn karaktè, koupe chenn nan tout kote ki gen espas. Epi afiche yon lis ki gen chak eleman yo.

chenn = "Ayibobo Ayiti Bo"
result = chenn.split()
print(result)  