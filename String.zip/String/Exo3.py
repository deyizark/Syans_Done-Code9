#Nan yon chenn karaktè, mete tout premye lèt chak mo an majiskil.

chenn = "ayibobo ayiti"
result = chenn.title()
print(result)  