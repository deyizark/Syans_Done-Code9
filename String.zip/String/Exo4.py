#Nan yon chenn karaktè, rekipere premye lèt chak mo. Epi afiche yon nouvo chenn ak tout inisyal sa yo.

chenn = "Ayibobo Ayiti"
lis = chenn.split()
rezilta = ""
for lis in lis:
    rezilta += lis[0]
print(rezilta) 