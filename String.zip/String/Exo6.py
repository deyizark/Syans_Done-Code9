#Mete yon chenn karaktè devan dèyè, answit mete l an majiskil

chenn = "Ayiti"
rezilta = chenn[::-1]
rezilta = rezilta.upper()
print(rezilta) 